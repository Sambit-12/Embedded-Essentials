# Embedded-Essentials

# StepIN-Case Study:
![Activity_Model](https://raw.githubusercontent.com/Sambit-12/Embedded-Essentials/main/Simulation%20Activity1/StepIN%20Case%20Study.jpg)
1. Button Sensor checks the person is sitting or not
2. Temperature sensor works as :

ADC Value (Temp Sensor)| Output PWM
----------|----------
0-200 | 20% - 20 °C
210-500 | 40% - 25 °C
510-700 | 70% - 29 °C
710-1024 | 95% - 33 °C
 
