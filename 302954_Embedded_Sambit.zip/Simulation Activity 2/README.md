# Activity 1 Procedure

# IMAGE-1
![Both Turned ON](https://raw.githubusercontent.com/Sambit-12/Embedded-Essentials/main/Simulation%20Activity1/Both%20Sensor%20Turned%20On.png)

# IMAGE-2
![Both Turned OFF](https://raw.githubusercontent.com/Sambit-12/Embedded-Essentials/main/Simulation%20Activity1/Both%20Sensor%20Turned%20off.png)

# IMAGE-3
![Seatbutton_On and Heater_off](https://raw.githubusercontent.com/Sambit-12/Embedded-Essentials/main/Simulation%20Activity1/Seatbutton_On%20and%20Heater_off.png)

# IMAGE-4
![Seatbutton_Off and Heater_on](https://raw.githubusercontent.com/Sambit-12/Embedded-Essentials/main/Simulation%20Activity1/Seatbutton_off%20and%20Heater_on.png)
