#include <avr/interrupt.h>
#include <avr/io.h>
#include <util/delay.h>
void InitUSART(int ubrr_value);
char USARTReadChar();
void USARTWriteChar(uint8_t data);
#ifndef FINALOUTPUT_H_INCLUDED
#define FINALOUTPUT_H_INCLUDED



#endif // FINALOUTPUT_H_INCLUDED
